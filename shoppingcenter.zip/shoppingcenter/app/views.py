import imp
from unicodedata import category
from django.forms import forms
from django.shortcuts import render
from rest_framework.views import APIView
from rest_framework import views
from .models import Product,Customer,Cart,OrderPlaced
from .form import CustomerRegistrationForm,CustomerProfileForm
from django.contrib import messages


class HomeView(views.APIView):
    def get(self,request):
        topwear = Product.objects.filter(category = 'TW')
        bottomwear = Product.objects.filter(category = 'BW')
        mobile = Product.objects.filter(category = 'M')
        return render(request, 'app/home.html', {'topwears':topwear, 'bottomwears':bottomwear,'mobiles':mobile})

class ProductDetailsView(views.APIView):
    def get(self,request,pk):
        product = Product.objects.get(pk=pk)
        return render(request,'app/productdetail.html', {'product':product})

class MobileData(views.APIView):
    def get(self,request,data=None):
      if data == None:
        mobilebrand = Product.objects.filter(category = 'M')
      elif data=='Nokia' or data=='Apple' or data=='One plus' or data=='OPPO' or data=='Redmi':
        mobilebrand = Product.objects.filter(category = 'M').filter(brand = data)
      elif data=='Below':
        mobilebrand = Product.objects.filter(category = 'M').filter(discounted_price__lt = 10000)
      elif data=='Above':
        mobilebrand = Product.objects.filter(category = 'M').filter(discounted_price__gt = 10000)
      data = {}
      data['brands'] = mobilebrand
      return render(request,'app/mobile.html',data)

class TopwearData(views.APIView):
    def get(self,request,data=None):
      if data == None:
        topwear = Product.objects.filter(category = 'TW')
      elif data=='Below':
        topwear = Product.objects.filter(category = 'TW').filter(discounted_price__lt = 500)
      elif data=='Above':
        topwear = Product.objects.filter(category = 'TW').filter(discounted_price__gt = 500)
      data = {}
      data['topwear'] = topwear
      return render(request,'app/topwear.html',data)

class BottomwearData(views.APIView):
    def get(self,request,data=None):
      if data == None:
        bottomwear = Product.objects.filter(category = 'BW')
      elif data=='Below':
        bottomwear = Product.objects.filter(category = 'BW').filter(discounted_price__lt = 500)
      elif data=='Above':
        bottomwear = Product.objects.filter(category = 'BW').filter(discounted_price__gt = 500)
      data = {}
      data['bottomwear'] = bottomwear
      return render(request,'app/bottomwear.html',data)

class CustomerRegistrationView(views.APIView):
    def get(self, request):
        form = CustomerRegistrationForm()
        return render(request, 'app/customerregistration.html',{'form':form})
    def post(self,request):
        form = CustomerRegistrationForm(request.POST)
        if form.is_valid():
            messages.success(request, "Congratulations!! Registered Successfully")
            form.save()
        return render(request, 'app/customerregistration.html',{'form':form})

class CustomerProfile(views.APIView):
    def get(self,request):
     form = CustomerProfileForm()
     return render(request,'app/profile.html',{'form':form, 'active':'btn-primary'})

    def post(self,request):
        form = CustomerProfileForm(request.POST)
        if form.is_valid():
            usr = request.user
            name = form.cleaned_data['name']
            locality = form.cleaned_data['locality']
            city = form.cleaned_data['city']
            state = form.cleaned_data['state']
            zipcode = form.cleaned_data['zipcode']
            reg = Customer(user=usr,name=name, locality=locality,city=city,state=state,zipcode=zipcode)
            reg.save()
            messages.success(request,'Congratulations!! Profile updated successfully')
        return render(request,'app/profile.html',{'form':form,'active':'btn-primary' })

def address(request):
 address = Customer.objects.filter(user=request.user)
 return render(request, 'app/address.html',{'add':address,'active':'btn-primary'})

       

def add_to_cart(request):
 return render(request, 'app/addtocart.html')

def buy_now(request):
 return render(request, 'app/buynow.html')



def orders(request):
 return render(request, 'app/orders.html')


def mobile(request):
 return render(request, 'app/mobile.html')

def login(request):
 return render(request, 'app/login.html')

def customerregistration(request):
 return render(request, 'app/customerregistration.html')

def checkout(request):
 return render(request, 'app/checkout.html')
