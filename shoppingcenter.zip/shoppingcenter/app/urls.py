import imp
from django.urls import path
from app import views
from django.conf import settings
from django.conf.urls.static import static
from .views import HomeView
from django.contrib.auth import views as auth_views
from .form import LoginForm,PasswordChangeForm,PasswordResetForm,SetPasswordForm

urlpatterns = [
    # path('', views.home),
    path('', views.HomeView.as_view(), name = 'home'),
    path('product-detail/<int:pk>', views.ProductDetailsView.as_view(), name='product-detail'),
    path('cart/', views.add_to_cart, name='add-to-cart'),
    path('buy/', views.buy_now, name='buy-now'),
    path('profile/', views.CustomerProfile.as_view(), name='profile'),
    path('address/', views.address, name='address'),
    path('orders/', views.orders, name='orders'),
    path('mobile/', views.MobileData.as_view(), name='mobile'),
    path('mobile/(?P<data>[-a-zA-Z0-9_]+)$', views.MobileData.as_view(), name='mobiledata'),
    path('topwear/', views.TopwearData.as_view(), name='topwear'),
    path('topwear/(?P<data>[-a-zA-Z0-9_]+)$', views.TopwearData.as_view(), name='topdata'),
    path('bottomwear/', views.BottomwearData.as_view(), name='bottomwear'),
    path('bottomwear/(?P<data>[-a-zA-Z0-9_]+)$', views.BottomwearData.as_view(), name='bottomdata'),
    path('accounts/login/', auth_views.LoginView.as_view(template_name = 'app/login.html',authentication_form=LoginForm), name='login'),
    path('logout/', auth_views.LogoutView.as_view(next_page='login'), name='logout'),
    path('passwordchange/', auth_views.PasswordChangeView.as_view(template_name='app/passwordchange.html',form_class=PasswordChangeForm, success_url='/passwordchangedone/'),name = 'passwordchange'),
    path('passwordchangedone/',auth_views.PasswordChangeView.as_view(template_name='app/passwordchangedone.html'),name='passwordchangedone'),
    path('password-reset/',auth_views.PasswordResetView.as_view(template_name='app/password_reset.html', form_class = PasswordResetForm),name='password_reset'),
    path('password-reset/done/',auth_views.PasswordResetDoneView.as_view(template_name='app/password_reset_done.html'),name='password_reset_done'),
    path('password-reset-confirm/<uidb64>/<token>/',auth_views.PasswordResetConfirmView.as_view(template_name='app/password_reset_confirm.html', form_class=SetPasswordForm),name='password_reset_confirm'),
    path('password-reset-complete/',auth_views.PasswordResetCompleteView.as_view(template_name='app/password_reset_complete.html'),name='password_reset_complete'),
    
    path('registration/', views.CustomerRegistrationView.as_view(), name='customerregistration'),
    path('checkout/', views.checkout, name='checkout'),
]+ static(settings.MEDIA_URL, document_root = settings.MEDIA_ROOT)
